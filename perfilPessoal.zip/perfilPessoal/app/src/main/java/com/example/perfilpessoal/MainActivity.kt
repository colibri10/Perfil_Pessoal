package com.example.perfilpessoal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nome = findViewById<TextView>(R.id.txtNome)
        val idade = findViewById<TextView>(R.id.txtIdade)
        val profissao = findViewById<TextView>(R.id.txtProfissao)
        val img = findViewById<ImageView>(R.id.userImg)

        if (intent.hasExtra("nome")) {
            nome.text = intent.getStringExtra("nome")
            idade.text = intent.getStringExtra("idade")
            profissao.text = intent.getStringExtra("profissao")
            val foto = intent.getIntExtra("foto", R.drawable.img)
            img.setImageResource(foto)
        }

        findViewById<Button>(R.id.btnEditar).setOnClickListener {
            val i = Intent(this, EditActivity::class.java)
            i.putExtra("nome", nome.text.toString())
            i.putExtra("idade", idade.text.toString())
            i.putExtra("profissao", profissao.text.toString())
            startActivity(i)
        }
    }
}
