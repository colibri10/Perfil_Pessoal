package com.example.perfilpessoal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class EditActivity : AppCompatActivity() {

    var fotoSelecionada = R.drawable.img

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        val nome = findViewById<EditText>(R.id.inputNome)
        val idade = findViewById<EditText>(R.id.inputIdade)
        val profissao = findViewById<EditText>(R.id.inputProfissao)
        val img = findViewById<ImageView>(R.id.imgPreview)

        nome.setText(intent.getStringExtra("nome"))
        idade.setText(intent.getStringExtra("idade"))
        profissao.setText(intent.getStringExtra("profissao"))

        findViewById<Button>(R.id.btnTrocarFoto).setOnClickListener {
            fotoSelecionada =
                if (fotoSelecionada == R.drawable.img) R.drawable.img_1
                else R.drawable.img
            img.setImageResource(fotoSelecionada)
        }

        findViewById<Button>(R.id.btnSalvar).setOnClickListener {
            val i = Intent(this, MainActivity::class.java)
            i.putExtra("nome", nome.text.toString())
            i.putExtra("idade", idade.text.toString())
            i.putExtra("profissao", profissao.text.toString())
            i.putExtra("foto", fotoSelecionada)
            startActivity(i)
        }
    }
}
